<template>
  <div id="app">
    <modals-container></modals-container>
    <div v-if="this.$session.get('logined') == 'Y'">
      <button @click="removeSession()">로그아웃</button>
    </div>
    <div v-if="this.$session.get('logined') != 'Y'">
      <button>
        <router-link :to="`/login`" >
          로그인 [{{ this.$session.get('logined') }}]
        </router-link>
      </button>
      <router-link :to="`/join`" >
        <button>회원가입</button>
      </router-link>
      <!--<button v-if="this.$session.get('logined') == 'Y'" type="button">팝업창 오픈</button>-->
      <button type="button" @click="open_modal()">팝업창 오픈</button>
    </div>
  </div>
</template>

<script>
import PopupView from './popup/Popup';

export default {
  name: "App",
  data: () => {
    return {
      is_show: false,
    }
  },
  // mounted() {
  //   this.open_modal();
  // },
  methods: {
    open_popup() {
      this.is_show = !this.is_show;
    },
    open_modal() {
      this.$modal.show(PopupView, {
        modal : this.$modal },
        {
          name: 'dynamic-modal',
          width: '754px',
          height: '404px',
          draggable: false,
          resizable: false,
      })
    },
    removeSession() {
      this.$session.set('logined', 'N');
      this.$router.go();
    }
  }
}
</script>

<style>

</style>